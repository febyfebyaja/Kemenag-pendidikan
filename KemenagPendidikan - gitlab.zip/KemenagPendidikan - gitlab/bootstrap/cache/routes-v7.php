<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PvcBPZU53Fs7cdXq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login/login-process' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Login-Process',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login/logout-process' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout-process',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Profile/Profil-view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Profile/Profile-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Profile-Update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Dashboard/Dashboard-view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/approveguru/PenerimaanGuru-view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'PenerimaanGuru',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/approveguru/PenerimaanGuru-approvedec' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'PenerimaanGuru-appdec',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/guru/Guru-view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Guru',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/guru/Guru-chgpwd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Guru-chgpwd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/guru/Guru-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Guru-destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BankSoal/BankSoal-View' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'BankSoal',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BankSoal/BankSoal-Insert' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'BankSoal-Input',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BankSoal/BankSoal-Update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'BankSoal-Edit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BankSoal/BankSoal-Delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'BankSoal-Delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BankSoal-Semua/BankSoal-semua-View' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'BankSoal-Semua',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/MateriDigital/MateriDigital-View' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'MateriDigital',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/MateriDigital/MateriDigital-Insert' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'MateriDigital-Input',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/MateriDigital/MateriDigital-Update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'MateriDigital-update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/MateriDigital/MateriDigital-Delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'MateriDigital-Delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/MateriDigital-Semua/MateriDigitial-semua-View' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'MateriDigital-Semua',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Sekolah/sekolah-view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Sekolah',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Sekolah/sekolah-imgchange' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Sekolah-ImgChange',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Sekolah/sekolah-process-input' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Sekolah-processInsert',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Sekolah/sekolah-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Sekolah-update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
    ),
    3 => 
    array (
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::PvcBPZU53Fs7cdXq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":289:{@2OIUzESPgFYLhbIGQBWR/ztwxQiB45CSJu6QuXwCk2g=.a:5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000047b073a80000000062a524ea";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::PvcBPZU53Fs7cdXq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\LoginController@index',
        'controller' => 'App\\Http\\Controllers\\LoginController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'Login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Login-Process' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login/login-process',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\LoginController@Login',
        'controller' => 'App\\Http\\Controllers\\LoginController@Login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/login',
        'where' => 
        array (
        ),
        'as' => 'Login-Process',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'logout-process' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login/logout-process',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\LoginController@LogOut',
        'controller' => 'App\\Http\\Controllers\\LoginController@LogOut',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/login',
        'where' => 
        array (
        ),
        'as' => 'logout-process',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Profile/Profil-view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@index',
        'controller' => 'App\\Http\\Controllers\\ProfileController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/Profile',
        'where' => 
        array (
        ),
        'as' => 'Profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Profile-Update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Profile/Profile-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfilController@update',
        'controller' => 'App\\Http\\Controllers\\ProfilController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/Profile',
        'where' => 
        array (
        ),
        'as' => 'Profile-Update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Dashboard/Dashboard-view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/Dashboard',
        'where' => 
        array (
        ),
        'as' => 'Dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'PenerimaanGuru' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'approveguru/PenerimaanGuru-view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\PenerimaanGuruController@index',
        'controller' => 'App\\Http\\Controllers\\PenerimaanGuruController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/approveguru',
        'where' => 
        array (
        ),
        'as' => 'PenerimaanGuru',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'PenerimaanGuru-appdec' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'approveguru/PenerimaanGuru-approvedec',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\PenerimaanGuruController@approvedecline',
        'controller' => 'App\\Http\\Controllers\\PenerimaanGuruController@approvedecline',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/approveguru',
        'where' => 
        array (
        ),
        'as' => 'PenerimaanGuru-appdec',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Guru' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'guru/Guru-view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\GuruController@index',
        'controller' => 'App\\Http\\Controllers\\GuruController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/guru',
        'where' => 
        array (
        ),
        'as' => 'Guru',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Guru-chgpwd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'guru/Guru-chgpwd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\GuruController@changepwd',
        'controller' => 'App\\Http\\Controllers\\GuruController@changepwd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/guru',
        'where' => 
        array (
        ),
        'as' => 'Guru-chgpwd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Guru-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'guru/Guru-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\GuruController@destroydata',
        'controller' => 'App\\Http\\Controllers\\GuruController@destroydata',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/guru',
        'where' => 
        array (
        ),
        'as' => 'Guru-destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'BankSoal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'BankSoal/BankSoal-View',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\BankSoalController@index',
        'controller' => 'App\\Http\\Controllers\\BankSoalController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/BankSoal',
        'where' => 
        array (
        ),
        'as' => 'BankSoal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'BankSoal-Input' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'BankSoal/BankSoal-Insert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\BankSoalController@inputsoal',
        'controller' => 'App\\Http\\Controllers\\BankSoalController@inputsoal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/BankSoal',
        'where' => 
        array (
        ),
        'as' => 'BankSoal-Input',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'BankSoal-Edit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'BankSoal/BankSoal-Update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\BankSoalController@edit',
        'controller' => 'App\\Http\\Controllers\\BankSoalController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/BankSoal',
        'where' => 
        array (
        ),
        'as' => 'BankSoal-Edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'BankSoal-Delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'BankSoal/BankSoal-Delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\BankSoalController@destroy',
        'controller' => 'App\\Http\\Controllers\\BankSoalController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/BankSoal',
        'where' => 
        array (
        ),
        'as' => 'BankSoal-Delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'BankSoal-Semua' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'BankSoal-Semua/BankSoal-semua-View',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\BankSoalController@index_view',
        'controller' => 'App\\Http\\Controllers\\BankSoalController@index_view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/BankSoal-Semua',
        'where' => 
        array (
        ),
        'as' => 'BankSoal-Semua',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'MateriDigital' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'MateriDigital/MateriDigital-View',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\MateriDigitalController@index',
        'controller' => 'App\\Http\\Controllers\\MateriDigitalController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/MateriDigital',
        'where' => 
        array (
        ),
        'as' => 'MateriDigital',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'MateriDigital-Input' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'MateriDigital/MateriDigital-Insert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\MateriDigitalController@uploadmateri',
        'controller' => 'App\\Http\\Controllers\\MateriDigitalController@uploadmateri',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/MateriDigital',
        'where' => 
        array (
        ),
        'as' => 'MateriDigital-Input',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'MateriDigital-update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'MateriDigital/MateriDigital-Update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\MateriDIgitalController@updatedata',
        'controller' => 'App\\Http\\Controllers\\MateriDIgitalController@updatedata',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/MateriDigital',
        'where' => 
        array (
        ),
        'as' => 'MateriDigital-update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'MateriDigital-Delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'MateriDigital/MateriDigital-Delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\MateriDIgitalController@destroy',
        'controller' => 'App\\Http\\Controllers\\MateriDIgitalController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/MateriDigital',
        'where' => 
        array (
        ),
        'as' => 'MateriDigital-Delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'MateriDigital-Semua' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'MateriDigital-Semua/MateriDigitial-semua-View',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\MateriDigitalController@index_view',
        'controller' => 'App\\Http\\Controllers\\MateriDigitalController@index_view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/MateriDigital-Semua',
        'where' => 
        array (
        ),
        'as' => 'MateriDigital-Semua',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Sekolah' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Sekolah/sekolah-view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\SekolahController@index',
        'controller' => 'App\\Http\\Controllers\\SekolahController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/Sekolah',
        'where' => 
        array (
        ),
        'as' => 'Sekolah',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Sekolah-ImgChange' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Sekolah/sekolah-imgchange',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\SekolahController@updateImage',
        'controller' => 'App\\Http\\Controllers\\SekolahController@updateImage',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/Sekolah',
        'where' => 
        array (
        ),
        'as' => 'Sekolah-ImgChange',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Sekolah-processInsert' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Sekolah/sekolah-process-input',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\SekolahController@insert',
        'controller' => 'App\\Http\\Controllers\\SekolahController@insert',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/Sekolah',
        'where' => 
        array (
        ),
        'as' => 'Sekolah-processInsert',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'Sekolah-update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Sekolah/sekolah-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'authlogin',
          2 => 'ActivationAccount',
        ),
        'uses' => 'App\\Http\\Controllers\\SekolahController@update',
        'controller' => 'App\\Http\\Controllers\\SekolahController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/Sekolah',
        'where' => 
        array (
        ),
        'as' => 'Sekolah-update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
