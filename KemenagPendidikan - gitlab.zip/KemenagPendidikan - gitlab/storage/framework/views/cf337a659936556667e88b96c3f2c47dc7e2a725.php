<?php if($paginator->lastPage() > 1): ?>
    <div class="flex-wr-s-c m-rl--7 p-t-15">
        
        <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
        <a href="<?php echo e($paginator->url($i)); ?>" class="flex-c-c pagi-item hov-btn1 trans-03 m-all-7 <?php echo e(($paginator->currentPage() == $i) ? 'page-active' : ''); ?>"><?php echo e($i); ?></a>
        <?php endfor; ?>
        
    </div>
</nav>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\KemenagPendidikan\resources\views/pagination/default.blade.php ENDPATH**/ ?>