

<?php $__env->startSection('content'); ?>
<h1 class="mt-4">Dashboard</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Dashboard</li>
</ol>
    <div class="row">
        <?php if($role == 1): ?>
        <div class="col-md-4">
            <div class="p-3 mb-3 text-white" style="background-color:#653208"> 
                Total Guru : <?php echo e($guru); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 mb-3 bg-danger text-white"> 
                Total guru Ditolak : <?php echo e($guruditolak); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 mb-3 bg-success text-white"> 
                Total Guru Diterima : <?php echo e($guruditerima); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 mb-3 bg-primary text-white"> 
                Total Bank Soal : <?php echo e($banksoal); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 mb-3 text-white" style="background-color:#20c997"> 
                Total Materi : <?php echo e($materidigital); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 mb-3 text-white" style="background-color:#0dcaf0"> 
                Total Sekolah : <?php echo e($sekolah); ?>

            </div>
        </div>
    </div>
    <?php else: ?> 
        <div class="col-md-4">
            <div class="p-3 mb-3 bg-primary text-white"> 
                Total Bank Soal <?php echo e($username); ?>: <?php echo e($banksoalself); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 mb-3 text-white" style="background-color:#3d0a91"> 
                Total Bank Soal keseluruhan: <?php echo e($banksoal); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 mb-3 text-white" style="background-color:#20c997"> 
                Total Materi <?php echo e($username); ?>: <?php echo e($materidigitalself); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 mb-3 text-white" style="background-color:#052c65"> 
                Total Materi keseluruhan: <?php echo e($materidigital); ?>

            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KemenagPendidikan\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>