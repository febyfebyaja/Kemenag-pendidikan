

<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table mr-1"></i>
        Persetujuan akun guru
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Foto Profil</th>
                        <th>NUPTK</th>
                        <th>No. KTP</th>
                        <th>Nama Lengkap</th>
                        <th>Email</th>
                        <th>Jenis Kelamin</th>
                        <th>Username</th>
                        <th>Alamat</th>
                        <th>Tanggal Lahir</th>
                        <th>No. Telp</th>
                        <th>Kata Sandi</th>
                        <th>Status</th>
                        <th>Hapus</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center">
                            <div  style="border-radius:5px;border:1px solid black;position: relative;display: inline-block;width:200px;height:100px;">
                                <img src="http://192.168.1.8:8000/images/profile/<?php echo e($gk->id_login); ?>.jpg" alt="" style="display: block;max-width:190px;max-height:90px;margin-left: auto; margin-right: auto;magin-top:auto;margin-bottom:auto;">
                            </div>
                        </td>
                        <td><?php echo e($gk->nuptk); ?></td>
                        <td><?php echo e($gk->no_ktp); ?></td>
                        <td><?php echo e($gk->nama_lengkap); ?></td>
                        <td><?php echo e($gk->email); ?></td>
                        <td>
                            <?php if($gk->jk == 1): ?>
                                Laki - Laki
                            <?php elseif($gk->jk == 2): ?>
                                Perempuan
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($gk->username); ?></td>
                        <td><?php echo e($gk->alamat); ?></td>
                        <td><?php echo e($gk->ttl); ?></td>
                        <td><?php echo e($gk->telp); ?></td>
                        <td><a href="#" data-pk="<?php echo e($gk->id_login); ?>" data-toggle="modal" data-target="#updatepwd" class="btn btn-primary changepwd">Ganti Kata Sandi</a></td>
                        <td>
                            <?php if($gk->status == 0): ?>
                                <span style="color:red;font-weight:bold;">Ditolak</span><br>
                                <span>
                                    Catatan: <br>
                                    <?php echo e($gk->catatan); ?>

                                </span>
                            <?php elseif($gk->status == 2): ?>  
                                <span style="color:green;font-weight:bold;">Diterima</span>                              
                            <?php endif; ?>
                        </td>
                        <td><a href="#" data-pk="<?php echo e($gk->id_login); ?>" data-toggle="modal" data-target="#deleteakun" class="deleteaccount"><i style="color:red" class="fas fa-times"></i></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div style="display: flex;justify-content: center;"><?php echo e($guru->links('pagination.default')); ?></div>
        </div>
    </div>
</div> 


<div class="modal fade" id="deleteakun" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Menambahkan Akun Admin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('Guru-destroy')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body" align="center">
                    Apakah anda yakin ingin menghapus akun ini ? <br>
                    <input type="hidden" name="pk" id="pk-destroy">
                    <input type="password" name="kataSandiSedangLogin" placeholder="Kata sandi akun anda" class="form-control" required>
                </div> 
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Hapus Akun</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </form>
        </div>
    </div>
</div>




<div class="modal fade" id="updatepwd" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Mengubah Kata sandi admin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('Guru-chgpwd')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body" align="center">
                    <div class="breadcrumb" align="left">
                        Catatan : <br>
                        - untuk kata sandi yang sedang login adalah dari akun yang lagi login sekarang
                    </div>
                    <input type="hidden" name="pk" id="pk-pwd">
                    <input type="password" name="kataSandiBaru" placeholder="Kata Sandi Baru" class="form-control" required><br>
                    <input type="password" name="kataSandiSedangLogin" placeholder="Kata sandi akun anda" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Ubah Kata Sandi</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $('.btn-approve').click(function(){
        var idnikah = $(this).attr('data-idguru');
        $('#approve-pk').val(idnikah);
    })

    $('.btn-decline').click(function(){
        var idnikah = $(this).attr('data-idguru');
        $('#decline-pk').val(idnikah);
    })

    $('.deleteaccount').click(function(){
        var pk = $(this).attr('data-pk');
        $('#pk-destroy').val(pk);
    })

    $('.changepwd').click(function(){
        var pk = $(this).attr('data-pk');
        $('#pk-pwd').val(pk);
    });

    $(document).ready(function() {
        $('table.table').DataTable({
            "bLengthChange": false,
            "searching": false,
            "paging":false,
            "bInfo":false,
            "ordering": false,
        });
    }); 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KemenagPendidikan\resources\views\pages\guru.blade.php ENDPATH**/ ?>