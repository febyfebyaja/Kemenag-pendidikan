

<?php $__env->startSection('content'); ?>
<script>
    function readURL(input) {
       if (input.files && input.files[0]) {
           var reader = new FileReader();

           reader.onload = function (e) {
               $('#imginsert').attr('src', e.target.result);
           };
           reader.readAsDataURL(input.files[0]);
       }
    }
</script>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active border border-dark" style="width:100%;">
        <form action="<?php echo e(route('Profile-Update')); ?>" method="post" enctype="multipart/form-data" style="width:100%">
            <?php echo csrf_field(); ?>
            <table align="center">
                <tr>
                    <td Colspan="3" style="color:black;font-weight:bold;" align="center" height="105px">Ubah Profile</td>
                </tr>
                <?php if($guru->catatan != NULL && $guru->status == 0): ?>
                <tr>
                    <td colspan="3" align="center">
                        <div class="bg-danger text-light" style="border-radius:5px;padding:5px;" align="left">
                            Catatan : <br>
                            <?php echo e($guru->catatan); ?>

                        </div>
                    </td>
                </tr>
                <?php endif; ?>
                <input type="hidden" name="pk" value="<?php echo e($guru->id_login); ?>">

                <tr>
                    <?php 
                    if(does_url_exists('http://192.168.1.9:8000/images/profile/'.$guru->id_login.'.jpg')): 
                        $filelocation = 'http://192.168.1.9:8000/images/profile/'.$guru->id_login.'.jpg';
                    else: 
                        $filelocation = '/admin/assets/img/uploadimg.png';
                    endif;
                    ?>
                    <td align="center" colspan="3">
                        <div style="border-radius:10px;border:1px solid black;background-color:#cccccc;width:200px;height:100px;position: relative;display: inline-block;">
                            <img src="<?php echo e($filelocation); ?>" alt="" id="imginsert" max-width="100px" height="98px">
                        </div><br>                                    
                        <input type="file" accept="image/jpg" name="gambarProfile" id="btnimginsert" onchange="readURL(this);">
                    </td>
                </tr>
                <tr>
                    <td width="47%" style="color:black;font-weight:bold;">No. KTP</td>
                    <td width="6%" align="center">:</td>
                    <td width="47%"><input type="number" name="noKtp" class="form-control" value="<?php echo e($guru->no_ktp); ?>" required></td>
                </tr>
                <tr>
                    <td width="47%" style="color:black;font-weight:bold;">NUPTK</td>
                    <td width="6%" align="center">:</td>
                    <td width="47%"><input type="number" name="nuptk" class="form-control" value="<?php echo e($guru->nuptk); ?>" required></td>
                </tr>
                <tr>
                    <td style="color:black;font-weight:bold;">Nama Lengkap</td>
                    <td align="center">:</td>
                    <td><input type="text" name="namaLengkap" class="form-control" value="<?php echo e($guru->nama_lengkap); ?>" required></td>
                </tr>
                <tr>
                    <td style="color:black;font-weight:bold;">Nama Pengguna</td>
                    <td align="center">:</td>
                    <td><?php echo e($guru->username); ?></td>
                </tr>
                <tr>
                    <td style="color:black;font-weight:bold;">Sekolah</td>
                    <td align="center">:</td>
                    <td>
                        <select name="sekolah" id="" class="form-control" required>
                            <option value="">Pilih Sekolah</option>
                            <?php $__currentLoopData = $sekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sk->id_sekolah); ?>" <?php if($guru->id_sekolah == $sk->id_sekolah): ?> selected <?php endif; ?>><?php echo e($sk->nama_sekolah); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td style="color:black;font-weight:bold;">Email</td>
                    <td align="center">:</td>
                    <td><?php echo e($guru->email); ?></td>
                </tr>
                <tr>
                    <td style="color:black;font-weight:bold;">No Telp</td>
                    <td align="center">:</td>
                    <td><input type="text" name="noTelp" class="form-control" value="<?php echo e($guru->telp); ?>" required></td>
                </tr>
                <tr>
                    <td style="color:black;font-weight:bold;">Tanggal Lahir</td>
                    <td align="center">:</td>
                    <td><input type="date" name="tanggalLahir" class="form-control" value="<?php echo e($guru->ttl); ?>" required></td>
                </tr>
                <tr>
                    <td style="color:black;font-weight:bold;">Alamat</td>
                    <td align="center">:</td>
                    <td><textarea name="alamat" class="form-control" cols="30" rows="5" required><?php echo e($guru->alamat); ?></textarea></td>
                </tr>
                <tr>
                    <td colspan="3" align="center" height="105px"><button type="submit" class="btn btn-primary">Ubah Data</button></td>
                </tr>
            </table>
        </form>
    </li>
</ol>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KemenagPendidikan\resources\views\pages\profile.blade.php ENDPATH**/ ?>