<!DOCTYPE html>
<html>
<head>
	<title>KEMENAG BIMAS BUDDHA Pendidikan</title>
	<link rel="stylesheet" type="text/css" href="/login/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="/login/img/wave.png">
	<div class="container">
		<div class="img">
			<img src="/login/img/logo-014.png">
		</div>
		<div class="login-content">
			<form action="<?php echo e(route('Login-Process')); ?>" method="post">
				<?php echo csrf_field(); ?>
				<img src="/login/img/avatar.svg">
				<h2 class="title">Selamat Datang</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Nama Pengguna</h5>
           		   		<input type="text" name="username" class="input">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Kata Sandi</h5>
           		    	<input type="password" name="password" class="input">
            	   </div>
            	</div>
            	<input type="submit" class="btn" value="Login">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="/login/js/main.js"></script>
	<?php echo $__env->make('sweetalert::alert', ['cdn' => "https://cdn.jsdelivr.net/npm/sweetalert2@9"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\KemenagPendidikan\resources\views/login.blade.php ENDPATH**/ ?>