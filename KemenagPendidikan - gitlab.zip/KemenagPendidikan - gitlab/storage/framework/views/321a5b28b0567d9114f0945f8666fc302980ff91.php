<?php 
$idrole = Session::get('id_role');
$gurucount = App\Models\Guru::where('status', 1)
             ->count();

?>
<style>
.badge {
  border-radius: 50%;
  background-color: red;
  color: white;
}
</style>

        <?php if($idrole == 1): ?>
            <?php 
                $idlogin = Session::get('idlogin');
                // $admvhr = App\Models\AdminVihara::join('profil_login', 'profil_login.id_profil', '=', 'admin_vihara.id_profil')
                //         ->join('login', 'admin_vihara.id_login', 'login.id_login')
                //         ->where('admin_vihara.id_login', $idlogin)
                //         ->first();
            ?>
                <a class="nav-link" href="<?php echo e(route('Dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <a class="nav-link" href="<?php echo e(route('PenerimaanGuru')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Menerima Akun Guru <?php if($gurucount != 0): ?> <span class="badge"><?php echo e($gurucount); ?></span> <?php endif; ?>
                </a>
                <a class="nav-link" href="<?php echo e(route('Guru')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Guru 
                </a>
                <a class="nav-link" href="<?php echo e(route('BankSoal')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-file"></i></div>
                    Bank Soal
                </a>
                <a class="nav-link" href="<?php echo e(route('MateriDigital')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-digital-tachograph"></i></div>
                    Materi Digital
                </a>
                <a class="nav-link" href="<?php echo e(route('Sekolah')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-school"></i></div>
                    Sekolah
                </a>
        <?php elseif($idrole == 5): ?>
        <?php
            $usernamemenu = Session::get('username');
            $idloginmenu      = Session::get('idlogin');
            $guruformenu  = App\models\Guru::join('login', 'login.id_profil', 'guru.id_profil')
                            ->where('id_login', $idloginmenu)
                            ->first();
        ?>
            <?php if($guruformenu->status == 2): ?>
            <a class="nav-link" href="<?php echo e(route('Dashboard')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Dashboard
            </a>
            <a class="nav-link" href="<?php echo e(route('BankSoal')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-file"></i></div>
                Bank Soal <?php echo e($usernamemenu); ?>

            </a>
            <a class="nav-link" href="<?php echo e(route('MateriDigital')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-digital-tachograph"></i></div>
                Materi Digital <?php echo e($usernamemenu); ?>

            </a>
            <a class="nav-link" href="<?php echo e(route('BankSoal-Semua')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-file"></i></div>
                Bank Soal
            </a>
            <a class="nav-link" href="<?php echo e(route('MateriDigital-Semua')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-digital-tachograph"></i></div>
                Materi Digital
            </a>
            <?php endif; ?>
        <?php endif; ?>
        <a class="nav-link" href="<?php echo e(route('logout-process')); ?>">
            <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
            Keluar
        </a>
    
<?php /**PATH D:\xampp\htdocs\KemenagPendidikan\resources\views\menu.blade.php ENDPATH**/ ?>