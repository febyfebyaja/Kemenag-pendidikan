

<?php $__env->startSection('content'); ?>
    welcome
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KemenagPendidikan\resources\views\pages\dashboard.blade.php ENDPATH**/ ?>